class Snake {
    public static void main(String[] args) {
        Model v = new Model(10, 10);
    }
}